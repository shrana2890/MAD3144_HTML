-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2018 at 07:51 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `airbnb`
--
CREATE DATABASE IF NOT EXISTS `airbnb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `airbnb`;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `Id` varchar(2) NOT NULL,
  `name` varchar(52) DEFAULT NULL,
  `type` varchar(18) DEFAULT NULL,
  `location` varchar(8) DEFAULT NULL,
  `price` varchar(5) DEFAULT NULL,
  `rating` varchar(6) DEFAULT NULL,
  `reviews` varchar(17) DEFAULT NULL,
  `superhost` varchar(9) DEFAULT NULL,
  `owner` varchar(7) DEFAULT NULL,
  `guests` varchar(6) DEFAULT NULL,
  `bedrooms` varchar(8) DEFAULT NULL,
  `beds` varchar(4) DEFAULT NULL,
  `bath` varchar(4) DEFAULT NULL,
  `free_cancellation` varchar(17) DEFAULT NULL,
  `description` varchar(498) DEFAULT NULL,
  `free_parking` varchar(12) DEFAULT NULL,
  `laptop_friendly_environment` varchar(25) DEFAULT NULL,
  `laundry` varchar(7) DEFAULT NULL,
  `wifi` varchar(4) DEFAULT NULL,
  `kitchen` varchar(7) DEFAULT NULL,
  `cable_tv` varchar(8) DEFAULT NULL,
  `room` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`Id`, `name`, `type`, `location`, `price`, `rating`, `reviews`, `superhost`, `owner`, `guests`, `bedrooms`, `beds`, `bath`, `free_cancellation`, `description`, `free_parking`, `laptop_friendly_environment`, `laundry`, `wifi`, `kitchen`, `cable_tv`, `room`) VALUES
('1', 'Sun Filled Photographic Hard Loft', 'Entire Loft', 'Toronto', '210', '5', '245', 'yes', 'Leslie', '2', '0', '1', '1', 'yes', 'Sunny Authentic Hard Loft. Voted \'Top Ten Airbnb Listings in Toronto,\' and featured in Toronto Life Magazine, \'Airbnb of the Week.\'\n\nHigh ceilings/ huge windows. Southern/ Eastern exposures. Brick walls/ wood floors. Top floor, corner unit. Heintzman Piano. Swing. Tons of natural light. Enquire for photo shoot rates.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', 'roomimages/01-01.jpg'),
('10', 'Affordable stay in Downtown Toronto', 'Private Room', 'Toronto', '36', '4', '233', 'no', '', '3', '1', '1', '1', 'yes', 'A beautiful, furnished, one bedroom in a semi detached house located between The Annex & Little italy.', 'no', 'no', 'no', 'yes', 'yes', 'no', ' roomimages/10-01.jpg'),
('11', 'Quaint Victorian Rowhouse Downtown Toronto', 'Private Room', 'Toronto', '68', '5', '138', 'no', '', '2', '1', '1', '1', 'yes', 'Conveniently walkable to Yonge & Dundas, the Distillery district, Leslieville, Cabbagetown and many TIFF venues. SO many fab restaurants nearby and any 1 of 3 streetcars can take you to the other side of the city. Parking on premises possible but not guaranteed. Check-in depends on the day...give me your estimated time of arrival and I will let you know if I can accommodate.\n\nNo microwave or access to cooking, but fridge, kettle & toaster are at your disposal.', 'no', 'yes', 'no', 'yes', 'no', 'no', ' roomimages/11-01.jpg'),
('12', 'Explore Toronto from a Renovated Studio', 'Private Room', 'Toronto', '133', '5', '227', 'no', '', '2', '0', '1', '1', 'yes', 'This is an updated studio apartment within a home. It is a basement suite with own separate entrance and its own kitchen bathroom ect.\n\nThere is an eat in kitchen with new appliances. The apartment is the basement to my other listing on here and the only shared space is the Laundry room. There is a 42inch flat screen tv with cable, along with wifi included. There is a dresser and a place to hang clothing.', 'no', 'no', 'yes', 'no', 'yes', 'yes', ' roomimages/12-01.jpg'),
('13', 'Luxury Downtown Toronto 1 Bedroom Suite', 'Entire Apartment', 'Brampton', '106', '4.5', '10', 'no', '', '2', '1', '1', '1', 'yes', 'Cozy Private apartment just for you in the heart of one of the most vibrant neighborhoods Toronto has to offer, Little Italy. 5 mins short walk to Bathurst subway station which takes you anywhere in the city.\n\nThis lively neighborhood is packed with trattorias, trendy restaurants, cafés, pool halls and some of the best bars in town. It\'s sidewalks are humming with activity on weekends, especially when the weather turns cozy, with locals and visitors alike sipping espresso on outdoor patios.', '', 'yes', 'yes', 'yes', 'yes', 'yes', ' roomimages/13-01.jpg'),
('14', 'Studio Apartment in Little Italy', 'Entire Apartment', 'Brampton', '135', '5', '29', 'no', '', '2', '1', '1', '1.5', 'yes', 'A spacious bedroom with two large windows in the heart of midtown Toronto in a beautifully, freshly renovated apartment. Steps away from the bus stop, 5 mins walk to subway, restaurants, Yorkdale Mall, 15 mins to downtown via subway, and easy access to absolutely every convenience you can think of.', 'no', 'yes', 'yes', 'yes', 'yes', 'yes', ' roomimages/14-01.jpg'),
('15', 'Scenic Master Bedroom with Bath, Balcony, and Closet', 'Private Room', 'Brampton', '114', '5', '84', 'no', '', '2', '1', '1', '2', 'yes', 'Unobstructed waterfront view and great location - walking distance from all major attractions in the downtown core. 5 minute walk to: Union Station, Air Canada Centre, Rogers Centre, Metro Toronto Convention Centre, Westin Harbour Castle, Toronto Islands Ferry, Entertainment District, CN Tower.', 'no', 'yes', 'yes', 'yes', 'no', 'no', ' roomimages/15-01.jpg'),
('16', 'Simple and Affordable Room ', 'Private Room', 'brampton', '56', '5', '619', 'yes', '', '3', '1', '1', '1', 'yes', 'Flexible check in/out, staying with me in top floor (24 stairs up) 40 year old sunny townhouse complex: 650 square feet electric heating. 8 mins from downtown by 24 hour transit/bike; 25 mins walk). A few small shops/restaurants nearby: sushi, greek, ethiopian, breakfast. lgbt positive. I cherish guests\' suggestions. Corktown neighbourhood is east of downtown, slowly growing, eclectic, working class and safe. Parking is behind the complex just 50 metres away. Anything you need, just ask!', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', ' roomimages/16-01.jpg'),
('17', '1B+Den Lakeview New Condo Air Canada Center', 'Entire Apartment', 'Toronto', '125', '5', '61', 'no', '', '4', '1', '2', '1', 'yes', 'This extraordinary new condo is in the heart of Toronto. It has been newly furnished with beautiful chandeliers, stone wall, accessories, extra lighting & furniture. Also with a large corner balcony you get some great views within the city and lake. Its location is very rare as it is one of the few roads in Toronto that connects the Rogers Centre, Ripley\'s aquarium and Air Canada Centre. It is a great spot if you are attending these venues as well as anything in Toronto\'s downtown core.', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', ' roomimages/17-01.jpg'),
('2', 'Stylish Loft! Steps to Trendy King & Queen West', 'Entire Loft', 'Toronto', '205', '5', '128', 'no', 'Paul', '4', '2', '2', '1', 'no', 'This bohemian style artist\'s loft space has tons of character. Tucked away in a 150-year-old historical casket factory, the building has been converted into unique studio spaces for artists and creatives of all sorts! Truly the last of its kind in the downtown core, conveniently located in the King West 10-minute walk to CN Tower/Rogers center, Queen West, King West, Kensington market and the Waterfront! Very accessible to Billy Bishop, Pearson and easy TTC access!', 'no', 'yes', 'no', 'yes', 'yes', 'no', ' roomimages/02-01.jpg'),
('3', 'Stylish Downtown Cosy Room', 'Private Room', 'Toronto', '61', '4.5', '241', 'no', 'Jenelle', '1', '1', '1', '2', 'yes', 'This is a lovely private room with one bed. \nThis a beautifully renovated 1890\'s Victorian townhome that is located in one of the major up and coming neighbourhoods in the city and walking distance to all downtown attractions and amenities. We have four guest bedrooms, Which offers a great opportunity to meet and chat with other people from all over the world.', 'no', 'yes', 'yes', 'yes', 'yes', 'no', ' roomimages/03-01.jpg'),
('4', 'Genuine Hard Loft in Historic Building', 'Entire Apartment', 'Toronto', '148', '5', '529', 'yes', 'Pritesh', '2', '0', '1', '1', 'yes', 'Open concept industrial loft, this artist studio features 12\' ceilings, state of the art kitchen, concrete floors, boutique style bathroom,indoor parking and 24h security. \nThe loft is located in a vibrant neighbourhood, within walking distance from the Distillery District, the beaches, Opera House and great restaurants.', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', ' roomimages/04-01.jpg'),
('5', 'Downtown, Convenient, and Modern Apt', 'Private Room', 'Toronto', '29', '4.5', '76', 'no', '', '2', '1', '1', '1', 'yes', 'We offer a nice, modern and clean room with a Queen-sized mattress, new furniture with a built-in closet which having enough space for your belongings and luggage. You’ll love my place because of the convenience. Our place is 2-3 mins walk from Pape Station (350m). Every needed store is walking distance. Great bars and pubs are one block away. My place is good for couples, solo adventurers, business travellers, and furry friends (pets)', 'yes', 'yes', 'yes', 'yes', 'yes', 'no', ' roomimages/05-01.jpg'),
('6', 'Luxurious Executive-Style Condo in Central Toronto', 'Entire Condominium', 'Toronto', '182', '5', '10', 'no', '', '5', '1', '3', '1', 'yes', 'The condo is right in the heart of Toronto\'s Entertainment District. From mighty Lake Ontario to the heights of the CN tower, and from Ripley\'s Aquarium to the cheering crowds at Rogers Center, the city\'s best sights are just a stone\'s throw away.', 'yes', 'yes', 'yes', 'yes', 'yes', 'yes', ' roomimages/06-01.jpg'),
('7', 'Toronto Tree Top Room', 'Private Room', 'Toronto', '45', '5', '65', 'no', '', '2', '1', '1', '1', 'yes', 'Bright, cozy room in a flat near universities and colleges. 3 minutes from the subway in downtown Toronto. Walking distance to galleries, restaurants, museums, theatres, cultural centres and more!', 'no', 'no', 'no', 'yes', 'no', 'no', ' roomimages/07-01.jpg'),
('8', 'Kensington Market, Sleeps 4!', 'Entire Apartment', 'Toronto', '87', '4', '93', 'no', '', '4', '0', '2', '1', 'yes', 'KENSINGTON MARKET!!\nAMAZING LOCATION!!\n\nYou will be living in the heart of Kensington Market, groceries, restaurants, bars, shops.', 'no', 'yes', 'no', 'yes', 'yes', 'no', ' roomimages/08-01.jpg'),
('9', 'Panoramic View, Downtown Toronto, Liberty Village!', 'Entire Apartment', 'Toronto', '154', '5', '9', 'no', '', '2', '1', '1', '1', 'yes', 'In the heart of Liberty Village, Williams Landing, Tim Hortons, Brazen Head, CIBC, TD, Exhibition, BMO Field, Lake Ontario, TTC (15 Min to Bloor), Metro, Close to Downtown, Toronto Island, Access to Gardiner and Lakeshore, King and Queen West shopping/Clubs.\n\nEnjoy Panoramic views of downtown and Lake Ontario, the average age of LV is 28. Ceiling to floor Windows, South/East Facing Balcony, Mid Century Modern decor, Private Bathroom. Good for couples, solo adventurers, and business travellers.', 'yes', 'yes', 'no', 'yes', 'yes', 'yes', ' roomimages/09-01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `imageid` varchar(2) CHARACTER SET utf8 NOT NULL,
  `pic1` varchar(60) NOT NULL,
  `pic2` varchar(60) NOT NULL,
  `pic3` varchar(60) NOT NULL,
  `pic4` varchar(60) NOT NULL,
  `pic5` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`imageid`, `pic1`, `pic2`, `pic3`, `pic4`, `pic5`) VALUES
('1', 'roomimages/01-01.jpg', 'roomimages/01-02.jpg', 'roomimages/01-03.jpg', 'roomimages/01-04.jpg', 'roomimages/01-05.jpg'),
('2', 'roomimages/02-01.jpg', 'roomimages/02-02.jpg', 'roomimages/02-03.jpg', 'roomimages/02-04.jpg', 'roomimages/02-05.jpg'),
('3', 'roomimages/03-01.jpg', 'roomimages/03-02.jpg', 'roomimages/03-03.jpg', 'roomimages/03-04.jpg', 'roomimages/03-05.jpg'),
('4', 'roomimages/04-01.jpg', 'roomimages/04-02.jpg', 'roomimages/04-03.jpg', 'roomimages/04-04.jpg', 'roomimages/04-05.jpg'),
('5', 'roomimages/05-01.jpg', 'roomimages/05-02.jpg', 'roomimages/05-03.jpg', 'roomimages/05-04.jpg', 'roomimages/05-05.jpg'),
('6', 'roomimages/06-01.jpg', 'roomimages/06-02.jpg', 'roomimages/06-03.jpg', 'roomimages/06-04.jpg', 'roomimages/06-05.jpg'),
('7', 'roomimages/07-01.jpg', 'roomimages/07-02.jpg', 'roomimages/07-03.jpg', 'roomimages/07-04.jpg', 'roomimages/07-05.jpg'),
('8', 'roomimages/08-01.jpg', 'roomimages/08-02.jpg', 'roomimages/08-03.jpg', 'roomimages/08-04.jpg', 'roomimages/08-05.jpg'),
('9', 'roomimages/09-01.jpg', 'roomimages/09-02.jpg', 'roomimages/09-03.jpg', 'roomimages/09-04.jpg', 'roomimages/09-05.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `professors`
--

CREATE TABLE `professors` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unikey` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `professors`
--

INSERT INTO `professors` (`id`, `name`, `unikey`) VALUES
(11, 'sukhwinder', ''),
(27, 'sukh', '00a95a94706b1f517f19ef83386dbd4c'),
(28, 'sukh', '00a95a94706b1f517f19ef83386dbd4c'),
(29, 's', '00a95a94706b1f517f19ef83386dbd4c');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`imageid`);

--
-- Indexes for table `professors`
--
ALTER TABLE `professors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `professors`
--
ALTER TABLE `professors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `images`
--
ALTER TABLE `images`
  ADD CONSTRAINT `images_ibfk_1` FOREIGN KEY (`imageid`) REFERENCES `cities` (`Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
