<?php

//  if ($_SERVER["REQUEST_METHOD"] == "GET"){
      // 1. Get location id from the URL
      $cardID = $_GET["pos"];

      // 2. DB: Connect to database
      $dbhost = "localhost";		// address of your database
      $dbuser = "root";					// database username
      $dbpassword = "";					// database password: on MAMP, this is "root"
      $dbname = "college";							// @TODO: database name
      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Query database for a location that matches the id
      $sql = "SELECT * FROM cities WHERE id=" . $cardID;

      $results = mysqli_query($conn, $sql);
      $x = mysqli_fetch_assoc($results);    //you don't need a while loop because you only get 1 thing back

      print_r($x);
?>

<!DOCTYPE html>
<html>
<head>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin|Libre+Baskerville|Source+Sans+Pro" rel="stylesheet">
     <script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
     <style type="text/css">
     /* #pic{
       width: 100%;
       height: 60%;
       position: absolute;
     } */
     .notification {
       height: 8%;
     }
     #star{
     	color: orange;
     }
     #star:hover{
     	color:grey;
     }


.card:hover{
opacity: 0.8;
box-shadow: 0.5px 2px 2px 0px;
}

     </style>
  </head>
</head>

<body>
<div class="section">
    <div class="container" style="margin-top:20%;width:70%; margin: 0 auto;">

      <div class="columns">

          <?php
            $x = mysqli_fetch_assoc($results);
            // $b = mysqli_fetch_assoc($img);
           //	echo $img["pic1"];
           echo ' <a href="home.php?pos='. $x["Id"] . '">';


         ?>

        <div class="column">
         <div class="card ">
          <div class="card-image">
            <figure class="image is-4by3">
              <img src="<?php echo $x["room"]?>" alt="Placeholder image">
            </figure>
          </div>
          <div class="card-content">
            <div class="content" style="font-family: FontAwesome;">
              <p class="title " style="font-family: 'Varela Round', sans-serif;font-size:16px;"><?php echo $x["type"]." ".$x["beds"]." ". "bed" ?></p>
                <p class="subtitle"style="font-family:'Varela Round', sans-serif;font-size:15px;"><?php echo $x["name"]?></p>
              <p style="font-style: 'Varela Round', sans-serif;font-size:17px;color:#533393"><?php echo "$".$x["price"]." CAD per Night"?></p>
              <form >
                <button type="submit" style="float:right">Confirm</button>
              </form>
              <a href="#" id="star" style="font-family: 'Varela Round', sans-serif;font-size:12px;">
                <?php
                    if( $q == 0){
                      for($a=1; $a<=5;$a++){
                        if($a <= $x["rating"]){

                        echo '<i class="fas fa-star " ></i>';

                     }else if(floor($x["rating"]) != round($x["rating"])){
                      echo '<i class="fas fa-star-half "></i>';
                     }
                     else{
                       echo '<i class="far fa-star "></i>';
                     }
              }
              $q = 1;
           }
                ?>

              </a>
              <?php
              echo $x["reviews"]." "."reviews";
              ?>


            </div>

          </div>
        </div>
      </div>
      <?php
    echo "</a>";
    ?>
  </a>
     <?php
           $q=0;
        $q=0;
          ?>
        </div>
      </div><br>

    </div>
<!-- <script src="script.js"></script> -->
</body>
</body>
</html>
