<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

      // 1. UI: GET the information from the form
      $u = $_POST["username"];
      $first = $_POST["firstName"];
      $last = $_POST["lastName"];
      $pass = $_POST["password"];
      $check = $_POST["checked"];
      // $dob = $_POST["DOB"];


      // 2. DB: connect to database

      // ----------------------------------------

      $dbhost = "localhost";
      $dbuser = "root";
      $dbpassword = "";
      $dbname = "airbnb";

      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // SQL QUERY: 'SELECT * FROM users where username="pritesh" and password="1234"';

// $query = "SELECT * from login WHERE username = '$u' and password = '$p'";
$query = "INSERT into user (username,first_name,last_name,password,checked) VALUES('$u','$first','$last','$pass','$check')";

      $results = mysqli_query($conn, $query);

      // 3. LOGIC: check if user is in the database
      // If in db, $y = 0
      // Otherwise, $y = 1

      // 4. If successful, redirect user to previous page
         if ($results) {
           header("Location: showAdmin.php");
         }
         // 5. If failure, show an error message
         else {
           echo "An error occured while saving your data.";
         }



      // ----------------------------------------
  }
?>






<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>Sign up</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
  </head>
<body>
<!-- main div -->


<div style="width:500px; margin:0 auto; margin-top: 10%; padding:20px; border:2px solid grey;">

<form action="addAdmin.php" method="POST">

<!-- -------------------------email address---------------------------- -->
<div class="field">
  <div class="control  has-icons-right">
    <input class="input" type="text" placeholder="admin Email Address" name="username">
    <span class="icon is-small is-right">
      <i class="fas fa-envelope"></i>
    </span>
  </div>
</div>
<!-- ------------------------------first name --------------------------->
<div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="First Name" name="firstName">
    <span class="icon is-small is-right">
      <i class="fas fa-user"></i>
    </span>
  </div>
</div>
<!-- ------------------------last name--------------------------------- -->
  <div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="Last Name" name="lastName">
    <span class="icon is-small is-right">
      <i class="fas fa-user"></i>
    </span>
  </div>
</div>
<!-- -----------------------password---------------------------------- -->
  <div class="field">
  <div class="control has-icons-right">
    <input class="input" type="text" placeholder="Create a Password" name="password">
  <span class="icon is-small is-right">
    <i class="fas fa-passport"></i>
    </span>
  </div>
</div>

<!------------------------checked------------------------------------->

  <div class="field">
  <div class="control">
    <input class="input" type="text" placeholder="true/false" name="checked">
  </div>
</div>


<p style="color:grey;">We'll send you marketing promotions, special offers, inspirations and policy updates via email</p>
<!--  -------------------     button------------------------------------->
<div class="field">
<div class="control">
  <button type="submit" class="button button is-danger is-fullwidth">Add Admin</button>
</div>
</div>

<p style="color:grey;">i don't want to recieve marketing messages from AirB&B. I can also opt out of receveing these at any time in my account setting or via the link in the message </p>
<!-- -----------------------------end of main div--------------------- -->
</form>
</div>

</body>
</html>
