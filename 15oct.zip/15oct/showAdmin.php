
<?php

// 1. connect to DATABASE

// 2. get all the rows back

// 3. show it in a table
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "airbnb";							// @TODO: database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
  $query = 'SELECT * FROM user';
  $results = mysqli_query($conn, $query);


?>

<!DOCTYPE html>
<html>
<head>
  <!-- bulma -->
  <link href="css/bulma.min.css" rel="stylesheet" type="text/css">
</head>
<body>
  <div class="content">
    <h1> users/Admin </h1>

    <!-- @TODO: make a table & put all the location data in it-->
    <!--------------------------------------------------->
    <?php
      while( $x = mysqli_fetch_assoc($results) ) {
        // clean up the user interface
        echo $x["username"] . " | ";
        echo $x["first_name"] . " | ";
        echo $x["last_name"]. " | ";

        // add an edit and delete button to each rows
        echo '<a href="editAdmin.php?pos='. $x["id"] . '">Edit</a> | ';
        echo '<a href="deleteAdmin.php>pos='. $x["id"] . '">Delete</a>';
        echo "<br>";
      }
    ?>

    <!--------------------------------------------------->
    <a href="addAdmin.php" class="button"> + Add Admin </a> <br><br>
    <a href="home.php" class="button"> < Go Home </a>
  </div>
</body>
</html>
