<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
  $id = $_GET["pos"];
  $dbhost = "localhost";    // address of your database
      $dbuser = "root";         // database username
      $dbpassword = "";         // database password: on MAMP, this is "root"
      $dbname = "airbnb";              // @TODO: database name
      $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);

      // 3. Query database for a location that matches the id
      echo $id;
      $sql = "DELETE from cities WHERE Id = $id";
      
      $results = mysqli_query($conn, $sql);
     // $x = mysqli_fetch_assoc($results);    //you don't need a while loop because you only get 1 thing back

  }
  ?>