<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <title>main page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.1/css/bulma.min.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin|Libre+Baskerville|Source+Sans+Pro" rel="stylesheet">
     <script defer src="https://use.fontawesome.com/releases/v5.1.0/js/all.js"></script>
  </head>
 <body style="margin-bottom: 10px;">

   <!-- MENU -->
 <nav class="navbar is-light">
  <div class="navbar-brand">
    <div class="navbar-burger burger" data-target="navbarExampleTransparentExample">
      <span></span>
      <span></span>
      <span></span>
    </div>
  </div>

  <div id="navbarExampleTransparentExample" class="navbar-menu">
    <div class="navbar-end">
      <a class="navbar-item" href="#">
        Terms And Conditions
      </a>
      <form class="navbar-item " action="signin.php" method="POST">
        <button class="button">logout</button>
      
      </form>
      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link" href="home.php"?pos= value>
          Currency
        </a>
        <div class="navbar-dropdown has-dropdown-up is-boxed">
          <a value=1 class="navbar-item" href="home.php"?pos= value>
            India
          </a>
          <a value =2 class="navbar-item" href="home.php"?pos= value>
            Canada
          </a>
          <a value = 3 class="navbar-item" href="home.php"?pos= value>
            USA
          </a>
        </div>
      </div>
    </div>
  </div>
</nav>

 </body>
 </html>
