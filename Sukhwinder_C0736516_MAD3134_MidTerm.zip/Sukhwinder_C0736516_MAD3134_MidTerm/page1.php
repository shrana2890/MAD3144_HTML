<?php
  $u = $_POST["name"];
  //echo $u;
  $p = $_POST["password"];
//  echo $p;
   session_start();

  if($u == "hungrytoronto" && $p == "imsohungry"){
    $_SESSION['name'] = "hungrytoronto";
     header("Location: page2.php");
  }
   else if($u == "jimmychin" && $p == "camera915"){
       $_SESSION['name'] = "jimmychin";
        header("Location: page2.php");
   }
  else {
      echo "invalid";

  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link href="https://fonts.googleapis.com/css?family=Satisfy" rel="stylesheet">
    <title>Instagram</title>
    <style type="text/css">
    h1{
      font-family: 'Satisfy', cursive;
    }

    </style>



    <!-- font awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- jquery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  </head>
  <body>
    <script src="index.js"></script>

 <div style="width:60%; margin: 0 auto;">
     <h1>Instagram</h1>
    <form action="page1.php" method="POST">
       <br> <input type="text" name="name" required placeholder="Phone number, username, or email"> <br>
      <br> <input type="text" name="password" required placeholder="Password: "> <br>
      <button type="submit"> Login </button>
    </form>

    <a href="page2.php"> Go to page 2 </a>
</div>
    <!-- javascript validation -->
    <script type="text/javascript">
      // i don't need you ha! :)
    </script>
  </body>
</html>
