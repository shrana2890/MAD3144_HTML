<?php
  // if ($_SERVER["REQUEST_METHOD"] == "GET") {
  // //  print_r($_GET["name"]);
  // }
  // else if ($_SERVER["REQUEST_METHOD"] == "POST") {
  //   print_r($_POST);
  // }
  // $user1 = [
  //    "username" => "hungrytoronto",
  //     "photos" => [
  //       photo1.png, photo2.png,photo3.png,photo4.png, photo5.png,photo6.png,photo7.png, photo8.png,photo9.png,photo10.png, photo11.png,photo12.png,photo13.png, photo14.png,photo15.png
  //     ],
  //     "profile" => "logoA.png"
  // ];
  // $user2 = [
  //    "username" => "jimmychin",
  //     "photos" => [
  //       photo1.png, photo2.png,photo3.png,photo4.png, photo5.png,photo6.png,photo7.png, photo8.png,photo9.png,photo10.png, photo11.png,photo12.png,photo13.png, photo14.png,photo15.png
  //     ],
  //     "profile" => "logoB.png"
  // ];
session_start();
$user = $_SESSION['name'];
?>
<html>
<head>
  <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
  <style type="text/css">
    body {
      font-family:"Roboto"
      width:10%;
      margin: 0 auto;
      padding: 28px;
    }
    h2 {
      font-size:16px;
    }
    p {
      font-size:20px;
    }
  </style>
</head>

<body>
<div style="width:70%"; margin: 0 auto;>
  <?php
      if ($user == "hungrytoronto") {
        echo  "<img src='photos/logos/logoA.png'>";
        echo "<br>";
        echo $user;
        echo "<br>";
        echo "<button type='submit' href='#' style='width:80px;height:30px;'>Follow </button>";
          echo "<br>";
      
        for ($i = 1; $i <= 15; $i++) {
          echo "<img src='photos/food/photo$i.png'>";
        }
}

     else {
       echo  "<img src='photos/logos/logoB.png'>";
         echo "<br>";
         echo $user;
         echo "<br>";
         echo "<button type='submit' href='#' style='width:80px;height:30px;'>Follow </button>";
           echo "<br>";
       for ($i = 1; $i <= 15; $i++) {
         echo "<img src='photos/climbing/photo$i.png'>";
       }
}
?>

</div>


</body>
</html>
