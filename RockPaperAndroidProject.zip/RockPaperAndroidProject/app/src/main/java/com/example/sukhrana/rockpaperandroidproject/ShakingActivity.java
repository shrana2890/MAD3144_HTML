package com.example.sukhrana.rockpaperandroidproject;

import android.content.DialogInterface;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.seismic.ShakeDetector;

import java.util.Random;


public class ShakingActivity extends AppCompatActivity implements ShakeDetector.Listener{
//
    int shakesCount = 0;
    int[] photos = {R.drawable.scissor,R.drawable.paper,R.drawable.rock,R.drawable.lizard,R.drawable.spock};

   Random ran = new Random();
   int i = ran.nextInt(photos.length);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shaking);
        SensorManager manager = (SensorManager) getSystemService(SENSOR_SERVICE);
        ShakeDetector detector = new ShakeDetector(this);
        detector.start(manager);

    }

    public void  WannaPaly(View view){
        AlertDialog.Builder alert = new AlertDialog.Builder(ShakingActivity.this);
        alert.setMessage("please shake your mobile three times again");
        alert.setNeutralButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(),"lets play again",Toast.LENGTH_SHORT).show();

            }
        });
        alert.show();


        i = ran.nextInt(photos.length);
       hearShake();


    }

    @Override
    public void hearShake() {

        shakesCount = shakesCount + 1;
        if (shakesCount >= 3) {
            Log.d("JENELLE", "phone is shaking!!!!");

            Toast.makeText(this, "PHONE IS SHAKING!!!!" + shakesCount, Toast.LENGTH_SHORT).show();
            ImageView image = (ImageView)findViewById(R.id.shakeImage);
            image.setImageResource(photos[i]);
            shakesCount = 0;

            //do code for sending data to each other and then
            //show who is win and who is loss
        }

    }
}
