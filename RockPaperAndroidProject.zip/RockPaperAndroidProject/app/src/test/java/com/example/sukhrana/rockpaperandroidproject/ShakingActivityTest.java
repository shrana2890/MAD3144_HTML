package com.example.sukhrana.rockpaperandroidproject;

import org.junit.Test;

import static org.junit.Assert.*;

public class ShakingActivityTest {

    @Test
    public void onCreate() {
    }
}